export class CustomerDetails {
    id!: number;
    firstname!: string;
    lastname!: string;
    age!: string;
    address!: string;
  }